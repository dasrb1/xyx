const express = require('express');
const app = express();
const path = require('path');
const port = process.env.PORT || 3000;

// 提供前端静态文件
app.use(express.static(path.join(__dirname, '../frontend')));

// 启动服务器
app.listen(port, () => {
    console.log(`后端服务器运行在 http://localhost:${port}`);
});